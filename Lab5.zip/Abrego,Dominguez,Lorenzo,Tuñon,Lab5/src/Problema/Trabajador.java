package Problema;

public class Trabajador {
	
	private String cedula = "";
	private String nombre = "";
	private String departamento = "";
	private String nombreDescuento = "";
	private double salarioBruto = 0.0;
	private double salarioNeto = 0.0;
	private String descuentoAdicional = "";
	private double descuento = 0.0;
	private double seguroSocial = 0.0;
	private double seguroEducativo = 0.0;
	
	public Trabajador(String cedula, String nombre, String departamento, String nombreDescuento, double salarioBruto, double salarioNeto, String descuentoAdicional, double descuento, double seguroSocial, double seguroEducativo) {
		this.cedula = cedula;
		this.nombre = nombre;
		this.departamento = departamento;
		this.nombreDescuento = nombreDescuento;
		this.salarioBruto = salarioBruto;
		this.salarioNeto = salarioNeto;
		this.descuentoAdicional = descuentoAdicional;
		this.descuento = descuento;
		this.seguroSocial = seguroSocial;
		this.seguroEducativo = seguroEducativo;
	}
	
	public String getCedula() {
		return cedula;
	}
	public void setCedula(String cedula) {
		this.cedula = cedula;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public double getSalarioBruto() {
		return salarioBruto;
	}
	public void setSalarioBruto(double salarioBruto) {
		this.salarioBruto = salarioBruto;
	}
	public double getSalarioNeto() {
		return salarioNeto;
	}
	public void setSalarioNeto(double salarioNeto) {
		this.salarioNeto = salarioNeto;
	}
	
	public String getDescuentoAdicional() {
		return descuentoAdicional;
	}

	public void setDescuentoAdicional(String descuentoAdicional) {
		this.descuentoAdicional = descuentoAdicional;
	}

	public String getNombreDescuento() {
		return nombreDescuento;
	}

	public void setNombreDescuento(String nombreDescuento) {
		this.nombreDescuento = nombreDescuento;
	}

	public double getDescuento() {
		return descuento;
	}

	public void setDescuento(double descuento) {
		this.descuento = descuento;
	}

	public double getSeguroSocial() {
		return seguroSocial;
	}

	public void setSeguroSocial(double seguroSocial) {
		this.seguroSocial = seguroSocial;
	}

	public double getSeguroEducativo() {
		return seguroEducativo;
	}

	public void setSeguroEducativo(double seguroEducativo) {
		this.seguroEducativo = seguroEducativo;
	}

	public void informacion() {
		 System.out.print("El salario bruto del empleado es: " + salarioBruto );
		 System.out.print("Descuento de seguro social: " + seguroSocial); 
		 System.out.print("Descuento de seguro educativo: " + seguroEducativo); 
		 System.out.print("El salario neto del empleado es" + salarioNeto); 
		 System.out.println("Descuento adicional: " + descuento);
		 System.out.println("El nombre del empleado es: " + nombre);
         System.out.println("El cédula del empleado es: " + cedula);
         System.out.println("El departamento del empleado es: " + departamento);
         System.out.println("Nombre de descuento adicional: "+ descuentoAdicional);
       
     
	}
}
