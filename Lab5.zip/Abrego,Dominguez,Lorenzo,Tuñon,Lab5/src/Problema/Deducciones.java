package Problema;

public class Deducciones {
    private double seguroSocial;
    private double seguroEducativo;
    private double deduccionExtra;
    private Trabajador trabajador;

    public Deducciones(Trabajador trabajador) {
        this.trabajador = trabajador;
        calcularSeguroSocial();
        calcularSeguroEducativo();
    }

    public double getSeguroSocial() {
        return seguroSocial;
    }

    public void setSeguroSocial(double seguroSocial) {
        if (seguroSocial > 0) {
            this.seguroSocial = seguroSocial;
        } else {
            System.out.println("El monto del seguro social no puede ser negativo.");
        }
    }

    public double getSeguroEducativo() {
        return seguroEducativo;
    }

    public void setSeguroEducativo(double seguroEducativo) {
        if (seguroEducativo > 0) {
            this.seguroEducativo = seguroEducativo;
        } else {
            System.out.println("El monto del seguro educativo no puede ser negativo.");
        }
    }

    public double getDeduccionExtra() {
        return deduccionExtra;
    }

    public void setDeduccionExtra(double deduccionExtra) {
        this.deduccionExtra = deduccionExtra;
    }

    private void calcularSeguroSocial() {
        this.seguroSocial = trabajador.getSalarioBruto() * 0.0975;
    }

    private void calcularSeguroEducativo() {
        this.seguroEducativo = trabajador.getSalarioBruto() * 0.0125;
    }

    public double calcularSalarioNeto(boolean aplicarOtraDeduccion) {
        
    	double deduccionTotal = seguroSocial + seguroEducativo;
        if (aplicarOtraDeduccion==true) {
            deduccionTotal = deduccionTotal + deduccionExtra;
        }
        double salarioNeto = trabajador.getSalarioBruto() - deduccionTotal;
        
        System.out.printf("Salario Bruto: %, Seguro Social: %, Seguro Educativo: %, Deducción Extra: $, Salario Neto: $",
                trabajador.getSalarioBruto(), seguroSocial, seguroEducativo, (aplicarOtraDeduccion ? deduccionExtra : 0.0), salarioNeto);

    return salarioNeto;}
}