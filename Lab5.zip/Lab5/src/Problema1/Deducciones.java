package Problema1;

public class Deducciones {

	public Deducciones() {
		// TODO Auto-generated constructor stub
	}

}
