package Problema1;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Principal {
    public static void main(String args[]) {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String nombre = " ";
        String cedula = " ";
        String departamento = " ";
        double salarioBruto = 0.0;
        double salarioNeto = 0.0;

        boolean nombreValido = false;
        boolean cedulaValida = false;
        boolean departamentoValido = false;
        boolean salarioBrutoValido = false;
        boolean salarioNetoValido = false;

        try {
            do {
                if (!nombreValido) {
                    System.out.println("Ingrese el nombre del empleado:");
                    nombre = reader.readLine();
                    if (nombre == " " || nombre.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el nombre del empleado.");
                        continue;
                    }
                    nombreValido = true;
                }

                if (!cedulaValida) {
                    System.out.println("Ingresa la cédula del empleado:");
                    cedula = reader.readLine();
                    if (cedula == " " || cedula.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese la cédula del empleado.");
                        continue;
                    }
                    cedulaValida = true;
                }
                
                if (!departamentoValido) {
                    System.out.println("Ingrese el departamento del empleado:");
                    departamento = reader.readLine();
                    if (departamento == " " || departamento.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el nombre del departamento.");
                        continue;
                    }
                    departamentoValido = true;
                }

                if (!salarioBrutoValido) {
                    System.out.println("Ingrese el salario bruto del empleado:");
                    String salarioBrutoStr = reader.readLine();
                    if (salarioBrutoStr == " " || salarioBrutoStr.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el salario bruto del empleado.");
                        continue;
                    }
                    try {
                        salarioBruto = Double.parseDouble(salarioBrutoStr);
                        if (salarioBruto <= 0.0) {
                            throw new NumberFormatException("Error negativo: El salario bruto no debe ser un valor negativo o cero. Ingrese el salario bruto correctamente.");
                        }
                        salarioBrutoValido = true;
                    } catch (NumberFormatException ex) {
                        System.out.println(ex.getMessage());
                        continue;
                    }
                }

                if (!salarioNetoValido) {
                    System.out.println("Ingrese el salario neto del empleado:");
                    String salarioNetoStr = reader.readLine();
                    if (salarioNetoStr == " " || salarioNetoStr.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el salario neto del empleado.");
                        continue;
                    }
                    try {
                        salarioNeto = Double.parseDouble(salarioNetoStr);
                        if (salarioNeto <= 0.0) {
                            throw new NumberFormatException("Error negativo: El salario neto no debe ser un valor negativo o cero. Ingrese el salario neto correctamente.");
                        }
                        salarioNetoValido = true;
                    } catch (NumberFormatException ex) {
                        System.out.println(ex.getMessage());
                        continue;
                    }
                }
                
            } while (!nombreValido || !cedulaValida || !departamentoValido || !salarioBrutoValido || !salarioNetoValido);

        } catch (IOException e) {
            System.err.println("Error de entrada/salida: " + e.getMessage());
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                System.err.println("Error al cerrar el BufferedReader: " + e.getMessage());
            }
            
       Trabajador trabajador = new Trabajador(cedula, nombre, departamento, departamento, 0, 0, 0);


        trabajador.setCedula(cedula);
        trabajador.setNombre(nombre);
        trabajador.setSalarioBruto(salarioBruto);
        trabajador.setSalarioNeto(salarioNeto);

        trabajador.informacion();
        
        }
    }
}