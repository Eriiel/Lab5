/**
 * 
 */
/**
 * 
 */
module LAB5 {
}