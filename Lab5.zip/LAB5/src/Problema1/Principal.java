package Problema1;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Principal {
    public static void main(String args[]) {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String nombre = "";
        String cedula = "";
        String departamento = "";
        String añadido = "";
        String descuentoAdicional = "";
        double salarioBruto = 0.0;
        double descuento = 0.0;

        boolean nombreValido = false;
        boolean cedulaValida = false;
        boolean departamentoValido = false;
        boolean añadidoValido = false;
        boolean nombreDescuentoValido = false;
        boolean salarioBrutoValido = false;
        boolean descuentoValido = false;

        try {
            do {
                if (!nombreValido) {
                    System.out.println("Ingrese el nombre del empleado:");
                    nombre = reader.readLine();
                    if (nombre.equalsIgnoreCase(" ") || nombre.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el nombre del empleado.");
                        continue;
                    }
                    nombreValido = true;
                }

                if (!cedulaValida) {
                    System.out.println("Ingresa la cédula del empleado:");
                    cedula = reader.readLine();
                    if (cedula.equalsIgnoreCase(" ") || cedula.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese la cédula del empleado.");
                        continue;
                    }
                    cedulaValida = true;
                }
                
                if (!departamentoValido) {
                    System.out.println("Ingrese el departamento del empleado:");
                    departamento = reader.readLine();
                    if (departamento.equalsIgnoreCase(" ") || departamento.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el nombre del departamento.");
                        continue;
                    }
                    departamentoValido = true;
                }

                if (!salarioBrutoValido) {
                    System.out.println("Ingrese el salario bruto mensual del empleado:");
                    String salarioBrutoStr = reader.readLine();
                    if (salarioBrutoStr.equalsIgnoreCase(" ") || salarioBrutoStr.trim().isEmpty()) {
                        System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el salario bruto del empleado.");
                        continue;
                    }
                    try {
                        salarioBruto = Double.parseDouble(salarioBrutoStr);
                        if (salarioBruto <= 0.0) {
                            throw new NumberFormatException("Error negativo: El salario bruto no debe ser un valor negativo o cero. Ingrese el salario bruto correctamente.");
                        }
                        salarioBrutoValido = true;
                    } catch (NumberFormatException ex) {
                        System.out.println(ex.getMessage());
                        continue;
                    }
                }
  
                
                if (!añadidoValido) {
                    System.out.println("¿Desea ingresar un descuento adicional? Escriba Si o No");
                    añadido = reader.readLine();
                    if (añadido.trim().isEmpty() || (!añadido.equalsIgnoreCase("Si") && !añadido.equalsIgnoreCase("No"))) {
                        System.out.println("Error: El valor a ingresar debe ser Si o No. Por favor, Intente otra vez.");
                        continue;
                    }
                    añadidoValido = true;
                }

                if (añadido.equalsIgnoreCase("Si")) {
                    if (!nombreDescuentoValido) {
                        System.out.println("Ingrese el nombre del descuento adicional:");
                        descuentoAdicional = reader.readLine();
                        if (descuentoAdicional.trim().isEmpty()) {
                            System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el nombre del descuento adicional.");
                            continue;
                        }
                        nombreDescuentoValido = true;
                    }
                    if (!descuentoValido) {
                        System.out.println("Ingrese en dolares el valor de su descuento adicional por mes:");
                        String descuentoStr = reader.readLine();
                        if (descuentoStr.trim().isEmpty()) {
                            System.out.println("Error: No puede dejar el parámetro en blanco. Por favor, Ingrese el valor de su descuento adicional.");
                            continue;
                        }
                        try {
                            descuento = Double.parseDouble(descuentoStr);
                            if (descuento <= 0.0) {
                                throw new NumberFormatException("Error negativo: El descuento adicional no debe ser un valor negativo o cero. Ingrese el descuento adicional correctamente.");
                            }
                            descuentoValido = true;
                        } catch (NumberFormatException ex) {
                            System.out.println(ex.getMessage());
                            continue;
                        }
                    }
                } else {
                    nombreDescuentoValido = true;
                    descuentoValido = true;
                    añadidoValido = true;
                }

            } while (!nombreValido || !cedulaValida || !departamentoValido || !salarioBrutoValido || !añadidoValido || !nombreDescuentoValido || !descuentoValido);

            
        } catch (IOException e) {
            System.err.println("Error de entrada/salida: " + e.getMessage());
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                System.err.println("Error al cerrar el BufferedReader: " + e.getMessage());
            }
        }
        
        Trabajador trabajador = new Trabajador(cedula, nombre, departamento, descuentoAdicional, salarioBruto);
        trabajador.informacion();

        Deducciones deducciones = new Deducciones(trabajador);
        deducciones.setDeduccionExtra(descuento);
        deducciones.calcularSalarioNeto(añadido.equalsIgnoreCase("Si"));
    }
}