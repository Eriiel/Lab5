package Problema1;

public class Trabajador {
    private String cedula;
    private String nombre;
    private String departamento;
    private String nombreDescuento;
    private double salarioBruto;

    public Trabajador(String cedula, String nombre, String departamento, String nombreDescuento, double salarioBruto) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.departamento = departamento;
        this.nombreDescuento = nombreDescuento;
        this.salarioBruto = salarioBruto;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public String getNombreDescuento() {
        return nombreDescuento;
    }

    public void setNombreDescuento(String nombreDescuento) {
        this.nombreDescuento = nombreDescuento;
    }

    public void informacion() {
        System.out.println("El nombre del empleado es: " + nombre);
        System.out.println("El cédula del empleado es: " + cedula);
        System.out.println("El departamento del empleado es: " + departamento);
        System.out.println("El salario bruto del empleado es: " + salarioBruto);
    }
}